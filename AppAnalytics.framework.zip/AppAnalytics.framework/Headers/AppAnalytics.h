//
// AppAnalytics
// Created by Shaun Merritt on 8/4/18.
// Copyright © 2018 ImagineSwift. All rights reserved.
// 

#import <UIKit/UIKit.h>

//! Project version number for AppAnalytics.
FOUNDATION_EXPORT double AppAnalyticsVersionNumber;

//! Project version string for AppAnalytics.
FOUNDATION_EXPORT const unsigned char AppAnalyticsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AppAnalytics/PublicHeader.h>


